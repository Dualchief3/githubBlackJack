package deckOfCards;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;

public class Deck {

	private final ArrayList<Card> listOfCards = new ArrayList<Card>();

	// constructor
	public Deck() {

		int suitCounter = 0;
		int ranksCounter = 0;

		Suit suits[] = { Suit.SPADES, Suit.HEARTS, Suit.CLUBS, Suit.DIAMONDS };

		Rank ranks[] = { Rank.ACE, Rank.TWO, Rank.THREE, Rank.FOUR, Rank.FIVE, Rank.SIX, Rank.SEVEN,

				Rank.EIGHT,

				Rank.NINE, Rank.TEN, Rank.JACK, Rank.QUEEN, Rank.KING };
		
		//For loop that starts to check card code
		for (int i = 0; i < 52; i++) {
			
			//if statement --> max rank is 13, we reset rank and move to next card type
			if (ranksCounter == 13) {
				
				ranksCounter = 0;
				suitCounter += 1;

			}
			
			//creating new Card object and adding to our list 
			Card card = new Card(ranks[ranksCounter], suits[suitCounter]);

			this.listOfCards.add(card);
			
			//increment rankCounter by 1 (index for array) 
			ranksCounter += 1;

		}


	}

	public ArrayList<Card> getListOfCards() {
		return listOfCards;
	}

	public void shuffle(Random randomNumberGenerator) {
		
		//first argument array of object, 2nd Random parameter 
		Collections.shuffle(listOfCards, randomNumberGenerator);
		 
	}

	public Card dealOneCard() {
		
		//pulling first card
		Card card = this.listOfCards.get(0); 
		
		//removing card from front
		this.listOfCards.remove(0); 
		
		//returning it 
		return card;
		
		
	}

	

	}


