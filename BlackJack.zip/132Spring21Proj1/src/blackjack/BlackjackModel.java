package blackjack;

import java.util.ArrayList;
import java.util.Random;

import deckOfCards.*;

public class BlackjackModel {

	private ArrayList<Card> dealerCards;
	private ArrayList<Card> playerCards;
	private Deck deck;

	public ArrayList<Card> getDealerCards() {

		ArrayList<Card> copiedDealerCards = new ArrayList<Card>(dealerCards);

		return copiedDealerCards; 

	}

	public ArrayList<Card> getPlayerCards() {

		ArrayList<Card> copiedPlayerCards = new ArrayList<Card>(playerCards);

		return copiedPlayerCards;

	}

	public void setDealerCards(ArrayList<Card> cards) {

		ArrayList<Card> copiedDealerCards = new ArrayList<Card>(cards);

		dealerCards = copiedDealerCards;

	}

	public void setPlayerCards(ArrayList<Card> cards) {

		ArrayList<Card> copiedPlayerCards = new ArrayList<Card>(cards);

		playerCards = copiedPlayerCards;

	}

	public void createAndShuffleDeck(Random random) {

		deck = new Deck();

		deck.shuffle(random);

	}

	public void initialDealerCards() {

		dealerCards = new ArrayList<Card>();

		dealerCards.add(deck.dealOneCard());
		dealerCards.add(deck.dealOneCard());

	}

	public void initialPlayerCards() {

		playerCards = new ArrayList<Card>();

		playerCards.add(deck.dealOneCard());
		playerCards.add(deck.dealOneCard());

	}

	public void playerTakeCard() {

		playerCards.add(deck.dealOneCard());

	}

	public void dealerTakeCard() {

		dealerCards.add(deck.dealOneCard());

	}

	public static ArrayList<Integer> possibleHandValues(ArrayList<Card> hand) {

		ArrayList<Integer> cardList = new ArrayList<Integer>();

		int handValueCounter = 0;
		int tempValue = 0;

		// Add deck of cards together in Hand
		for (int i = 0; i < hand.size(); i++) {

			// ** We need to somehow add in a second integer if you have an Ace card in hand
			handValueCounter += hand.get(i).getRank().getValue();

			// check our hand for Aces now
			if (hand.get(i).getRank() == Rank.ACE) {

				tempValue = handValueCounter;
				tempValue += 11;

				// if our current Hand will be bigger than 21
				if (tempValue > 21) {

					// choose Ace as 1
					handValueCounter += 1;

				}
				// if our current Hand will be smaller than 21
				else {

					// choose Ace as 11
					handValueCounter += 11;
				}
			}
			// if current Hand didn't have Ace
			else {

				handValueCounter += hand.get(i).getRank().getValue();
			}
		}

		cardList.add(handValueCounter);

		return cardList;
	}

	public static HandAssessment assessHand(ArrayList<Card> hand) {

		int i = 0;

		// if we have less than two cards - INSUFFICIENT CARDS
		if (hand == null || hand.size() < 2) {
			// **Check if it's OR NULL
			return HandAssessment.INSUFFICIENT_CARDS;
		}

		// If we have a 10 or Face Card and Ace (maximum of two cards) - NATURAL
		// BLACKJACK
		else {

			if (hand.size() == 2 && possibleHandValues(hand).contains(21)) {

				return HandAssessment.NATURAL_BLACKJACK;

				// For if hand is greater than 21 --> a BUST
			} else if (SumOfCardsInHand(hand) > 21) {

				return HandAssessment.BUST;

			} else {

				return HandAssessment.NORMAL;
			}

		}

	}

	public GameResult gameAssessment() {

		ArrayList<Integer> cardValuePlayer = possibleHandValues(playerCards);

		int playerValueHolder = 0;

		if (cardValuePlayer.size() == 2) {

			playerValueHolder = cardValuePlayer.get(1);

		} else {

			playerValueHolder = cardValuePlayer.get(0);

		}

		ArrayList<Integer> cardValueDealer = possibleHandValues(dealerCards);

		int dealerValueHolder = 0;

		if (cardValueDealer.size() == 2) {

			dealerValueHolder = cardValueDealer.get(1);

		} else {

			dealerValueHolder = cardValueDealer.get(0);
		}

		// initializes player for game assessment
		HandAssessment playerAssess = assessHand(playerCards);

		// initializes dealer for game assessment
		HandAssessment dealerAssess = assessHand(dealerCards);

		// Win/Loss Conditions

		if (playerAssess == HandAssessment.BUST) {

			return GameResult.PLAYER_LOST;

		}

		if (playerAssess == HandAssessment.NATURAL_BLACKJACK && dealerAssess != HandAssessment.NATURAL_BLACKJACK) {

			return GameResult.NATURAL_BLACKJACK;

		}

		if (playerAssess == HandAssessment.NORMAL && dealerAssess == HandAssessment.NORMAL) {

			if (dealerValueHolder > playerValueHolder) {

				return GameResult.PLAYER_LOST;

			} else if (dealerValueHolder < playerValueHolder) {

				return GameResult.PLAYER_WON;

			} else {

				return GameResult.PUSH;
			}

		}

		return GameResult.PLAYER_LOST;

	}

	public boolean dealerShouldTakeCard() {

		ArrayList<Integer> dealerHandValue = possibleHandValues(dealerCards);

		// if Dealers hand is 16 or less, continue taking cards
		if (dealerHandValue.get(0) <= 16) {

			dealerTakeCard();
			return true;

			// if dealers hand has more than 18 cards, dont take any more
		} else if (dealerHandValue.get(0) >= 18) {

			int aceValueInHand = 0;
			int totalValueInHand = 0;

			// checking if we have an Ace in hand
			for (int i = 0; i < dealerHandValue.size(); i++) {

				if (dealerCards.get(i).getRank() == Rank.ACE) {

					aceValueInHand = i;

				} else {

					totalValueInHand += dealerCards.get(i).getRank().getValue();

				}

			}
			//We have an ace in hand 
			if (aceValueInHand != 0) {

				totalValueInHand += dealerCards.get(aceValueInHand).getRank().getValue();
				//dealer's hand is greater than 18
				if (totalValueInHand >= 18) {

					return false;
				}

				else {

					return true;
				}
				
				//if dealer's hand is either 7 or 17 and has an Ace, she must take a Card
			} else if (aceValueInHand != 0 && dealerHandValue.get(0) == 7 
					|| dealerHandValue.get(0) == 17) {
				
				dealerTakeCard();
				return true;
			}
			
			//Dealers hand valued at 17 and not 7, must stop taking cards 
			else if (dealerHandValue.get(0) == 17) {

				return false;

			}

		}
		return false;

	}

	private static int SumOfCardsInHand(ArrayList<Card> hand) {

		int handHolder = 0;

		for (int i = 0; i < hand.size(); i++) {

			handHolder += hand.get(i).getRank().getValue();

		}

		return handHolder;

	}

}